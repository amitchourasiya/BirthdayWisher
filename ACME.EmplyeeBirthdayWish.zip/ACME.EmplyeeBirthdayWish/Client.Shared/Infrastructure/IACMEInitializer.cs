﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACME.EmplyeeBirthdayWish.Client.Shared.Infrastructure
{
    public interface IACMEInitializer
    {
       // IEventAggregator EventAggregator { get; }
    }
}
