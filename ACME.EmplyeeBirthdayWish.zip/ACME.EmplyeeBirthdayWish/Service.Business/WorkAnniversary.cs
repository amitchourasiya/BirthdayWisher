﻿using ACME.EmplyeeBirthdayWish.CrossCutting.DTO;
using ACME.EmplyeeBirthdayWish.Service.Shared.Providers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ACME.EmplyeeBirthdayWish.Service.Business
{
    public class WorkAnniversary: IWorkAnniversary
    {
        public List<Employee> GetWorkAnniversary()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

    }

}
