﻿using System;

namespace ACME.EmplyeeBirthdayWish.Service.Data
{
    public class DalBase : IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
