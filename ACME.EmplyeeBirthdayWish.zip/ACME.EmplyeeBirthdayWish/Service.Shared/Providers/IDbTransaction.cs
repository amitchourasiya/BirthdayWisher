﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACME.EmplyeeBirthdayWish.Service.Shared.Providers
{
    public interface IDbTransaction : IDisposable
    {
        
    }
}
